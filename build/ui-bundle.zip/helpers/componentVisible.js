'use strict'

module.exports = (component) => component.versions.find((componentVersion) =>
  !componentVersion.visibility || componentVersion.visibility.includes('prerelease'))
