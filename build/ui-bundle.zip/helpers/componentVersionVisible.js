'use strict'

module.exports = (componentVersion) =>
  !componentVersion.visibility || componentVersion.visibility.includes('prerelease')
